package com.example.tylerrapeweighttrackingapp;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class DataDispActivity extends AppCompatActivity{

    private RecyclerView weightRecyclerView;
    private EditText weightInput;
    private Button addWeightButton;

    private AppDatabaseHelper dbHelper;
    private WeightAdapter adapter;
    private TextView goalWeightText;
    private Button buttonSetGoalWeight;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data_display);

        goalWeightText = findViewById(R.id.textGoalWeight);
        buttonSetGoalWeight = findViewById(R.id.buttonSetGoalWeight);

        SharedPreferences prefs = getSharedPreferences("AppPrefs", MODE_PRIVATE);
        float goalWeight = prefs.getFloat("goal_weight", 0);
        if (goalWeight > 0) {
            goalWeightText.setText("Goal Weight: " + goalWeight + " lbs");
        }

        buttonSetGoalWeight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showSetGoalWeightDialog();
            }

        });

        dbHelper = new AppDatabaseHelper(this);

        weightRecyclerView = findViewById(R.id.weightRecyclerView);
        weightInput = findViewById(R.id.weightInput);
        addWeightButton = findViewById(R.id.addWeightButton);

        weightRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        loadWeights();

        addWeightButton.setOnClickListener(v -> {
            String weightStr = weightInput.getText().toString().trim();
            if (weightStr.isEmpty()) {
                Toast.makeText(this, "Please enter weight", Toast.LENGTH_SHORT).show();
                return;
            }

            try {
                float weight = Float.parseFloat(weightStr);
                dbHelper.addWeight(weight);
                weightInput.setText("");
                loadWeights();
            } catch (NumberFormatException e) {
                Toast.makeText(this, "Invalid weight", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void loadWeights() {
        List<WeightEntry> weightList = dbHelper.getAllWeights();
        adapter = new WeightAdapter(weightList, new WeightAdapter.WeightClickListener() {
            @Override
            public void onWeightClick(WeightEntry entry) {
                showEditDialog(entry);
            }

            @Override
            public void onWeightLongClick(WeightEntry entry) {
                dbHelper.deleteWeight(entry.getID());
                loadWeights();
            }
        });
        weightRecyclerView.setAdapter(adapter);
    }

    private void showEditDialog(WeightEntry entry) {
        final EditText editInput = new EditText(this);
        editInput.setText(String.valueOf(entry.getWeight()));

        new AlertDialog.Builder(this)
                .setTitle("Update Weight")
                .setView(editInput)
                .setPositiveButton("Update", (dialog, which) -> {
                    String newWeightStr = editInput.getText().toString().trim();
                    try {
                        float newWeight = Float.parseFloat(newWeightStr);
                        dbHelper.updateWeight(entry.getID(), newWeight);
                        loadWeights();
                    }catch (NumberFormatException e) {
                        Toast.makeText(this, "Invalid weight", Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void showSetGoalWeightDialog() {
        final EditText input = new EditText(this);
        input.setHint("Enter goal weight");

        new AlertDialog.Builder(this)
                .setTitle("Set goal weight")
                .setView(input)
                .setPositiveButton("Save", (dialog, which) -> {
                    try {
                        float goalWeight = Float.parseFloat(input.getText().toString().trim());
                        SharedPreferences prefs = getSharedPreferences("AppPrefs", MODE_PRIVATE);
                        prefs.edit().putFloat("goal_weight", goalWeight).apply();
                        goalWeightText.setText("Goal Weight: " + goalWeight + " lbs");
                        Toast.makeText(this, "Goal Weight saved", Toast.LENGTH_SHORT).show();
                    } catch (NumberFormatException e) {
                        Toast.makeText(this, "Invalid input", Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }
}
