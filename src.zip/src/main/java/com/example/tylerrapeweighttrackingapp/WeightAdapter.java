package com.example.tylerrapeweighttrackingapp;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class WeightAdapter extends RecyclerView.Adapter<WeightAdapter.WeightViewHolder> {

    public interface WeightClickListener {
        void onWeightClick(WeightEntry entry);
        void onWeightLongClick(WeightEntry entry);
    }

    private List<WeightEntry> weightList;
    private WeightClickListener listener;

    public WeightAdapter(List<WeightEntry> weightList, WeightClickListener listener) {
        this.weightList = weightList;
        this.listener = listener;
    }

    @NonNull
    @Override
    public WeightViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.weight_item, parent, false);
        return new WeightViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull WeightViewHolder holder, int position) {
        WeightEntry entry = weightList.get(position);
        holder.bind(entry);
    }

    @Override
    public int getItemCount() {
        return weightList.size();
    }

    class WeightViewHolder extends RecyclerView.ViewHolder {

        TextView weightText, timestampText;

        public WeightViewHolder(@NonNull View itemView) {
            super(itemView);
            weightText = itemView.findViewById(R.id.weightText);
            timestampText = itemView.findViewById(R.id.timestampText);
        }

        void bind(final WeightEntry entry) {
            weightText.setText("Weight: " + entry.getWeight() + " lbs");
            timestampText.setText("Date: " + entry.getTimestamp());

            itemView.setOnClickListener(v -> listener.onWeightClick(entry));
            itemView.setOnLongClickListener(v -> {
                listener.onWeightLongClick(entry);
                return true;
            });
        }
    }
}
