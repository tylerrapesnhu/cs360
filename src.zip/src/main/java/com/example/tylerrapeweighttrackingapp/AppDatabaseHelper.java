package com.example.tylerrapeweighttrackingapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;
public class AppDatabaseHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "weightTracker.db";
    private static final int DATABASE_VERSION = 6;
    private static final String TABLE_WEIGHT = "weights";
    private static final String COLUMN_WEIGHT_ID = "id";
    private static final String COLUMN_WEIGHT_VALUE = "weight";
    private static final String COLUMN_WEIGHT_TIMESTAMP = "timestamp";


    private static final String TABLE_USERS = "users";
    private static final String COLUMN_USER_ID = "id";
    private static final String COLUMN_USERNAME = "username";
    private static final String COLUMN_PASSWORD = "password";

    public AppDatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        Log.d("AppDB", "Creating weight and user tables");

        String CREATE_WEIGHT_TABLE = "CREATE TABLE " + TABLE_WEIGHT + "(" +
                COLUMN_WEIGHT_ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
                COLUMN_WEIGHT_VALUE + " REAL," +
                COLUMN_WEIGHT_TIMESTAMP + " DATETIME DEFAULT CURRENT_TIMESTAMP)";
        db.execSQL(CREATE_WEIGHT_TABLE);

        String CREATE_USERS_TABLE = "CREATE TABLE " + TABLE_USERS + "("
                + COLUMN_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + COLUMN_USERNAME + " TEXT UNIQUE,"
                + COLUMN_PASSWORD + " TEXT)";
        db.execSQL(CREATE_USERS_TABLE);
    }

    @Override
    public void onUpgrade (SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_WEIGHT);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        onCreate(db);
    }

    public void addWeight(float weight) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_WEIGHT_VALUE, weight);
        db.insert(TABLE_WEIGHT, null, values);
        db.close();
    }

    public List<WeightEntry> getAllWeights() {
        List<WeightEntry> weights = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_WEIGHT,
                new String[]{COLUMN_WEIGHT_ID, COLUMN_WEIGHT_VALUE, COLUMN_WEIGHT_TIMESTAMP},
                null, null, null, null,
                COLUMN_WEIGHT_TIMESTAMP + " DESC");

        if (cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_WEIGHT_ID));
                float weight = cursor.getFloat(cursor.getColumnIndexOrThrow(COLUMN_WEIGHT_VALUE));
                String timestamp = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_WEIGHT_TIMESTAMP));
                weights.add(new WeightEntry(id, weight, timestamp));
            } while (cursor.moveToNext());
            cursor.close();
        }
        db.close();
        return weights;
    }

    public void updateWeight(int id, float newWeight) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_WEIGHT_VALUE, newWeight);
        db.update(TABLE_WEIGHT, values, COLUMN_WEIGHT_ID + "=?", new String[]{String.valueOf(id)});
        db.close();
    }

    public void deleteWeight(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_WEIGHT, COLUMN_WEIGHT_ID + "=?", new String[]{String.valueOf(id)});
        db.close();
    }
    public boolean checkUser(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_USERS,
                new String[]{COLUMN_USER_ID},
                COLUMN_USERNAME + "=? AND " + COLUMN_PASSWORD + "=?",
                new String[]{username, password},
                null,null, null);

        boolean exists = (cursor != null && cursor.moveToFirst());
        if (cursor != null) cursor.close();
        db.close();
        return exists;
    }

    public boolean registerUser(String username, String password) {
        if (usernameExists(username)) {
            return false;
        }
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_USERNAME, username);
        values.put(COLUMN_PASSWORD, password);

        long result = db.insert(TABLE_USERS, null, values);
        db.close();
        return result != -1;
    }

    private boolean usernameExists(String username) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_USERS,
                new String[]{COLUMN_USER_ID},
                COLUMN_USERNAME + "=?",
                new String[]{username},
                null, null, null);

        boolean exists = (cursor != null && cursor.moveToFirst());
        if (cursor != null) cursor.close();
        db.close();
        return exists;
    }
}
