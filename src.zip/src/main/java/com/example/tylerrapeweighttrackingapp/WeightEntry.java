package com.example.tylerrapeweighttrackingapp;

public class WeightEntry {
    private int id;
    private float weight;
    private String timestamp;

    public WeightEntry(int id, float weight, String timestamp) {
        this.id = id;
        this.weight = weight;
        this.timestamp = timestamp;
    }

    public int getID() {
        return id;
    }

    public float getWeight() {
        return weight;
    }

    public String getTimestamp() {
        return timestamp;
    }

    public void setWeight(float weight) {
        this.weight = weight;
    }

    public void setTimestamp(String timestamp) {
        this.timestamp = timestamp;
    }
}
